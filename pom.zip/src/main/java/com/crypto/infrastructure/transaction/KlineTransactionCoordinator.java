package com.crypto.infrastructure.transaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.time.Instant;

/** FIX-124: commit market input before locking a position. Execute protection
 * before publishing the closed-candle event, preserving that ordering. No outer
 * transaction may retain candle locks while a protection transaction runs.
 */
@Service
public class KlineTransactionCoordinator {
    private static final Logger log = LoggerFactory.getLogger(KlineTransactionCoordinator.class);
    private static final int MAX_ATTEMPTS = 2;
    private KlineTiming timing = KlineTiming.loggingOnly();
    @org.springframework.beans.factory.annotation.Autowired
    public void setTiming(KlineTiming timing) { this.timing = timing; }
    private final TransactionTemplate transaction;
    private final Fix124ProtectionStore diagnostics;

    public KlineTransactionCoordinator(PlatformTransactionManager manager, Fix124ProtectionStore diagnostics) {
        transaction = new TransactionTemplate(manager);
        transaction.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        // FIX-153: current committed ordering after consistency locks; bound JDBC transaction work.
        transaction.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
        transaction.setTimeout(30);
        this.diagnostics = diagnostics;
    }

    public void process(String symbol, String interval, Instant candleOpenTime, Instant observedAt,
                        BigDecimal price, Runnable persistInput, Runnable protect,
                        Runnable observe, Runnable publishClosed) {
        var context = timing.context(symbol, interval, candleOpenTime, observedAt, null);
        // Candle and exact canonical price observation commit together. A failed
        // input write must not produce an unrecorded protection decision.
        try {
            timing.measure(context,"INPUT_TRANSACTION",false,()->transaction.executeWithoutResult(tx->persistInput.run()));
            com.crypto.local.LocalRuntimeDiagnostics.count(com.crypto.local.LocalRuntimeDiagnostics.Event.INPUT_COMMITTED);
        }catch(RuntimeException failure){
            com.crypto.local.LocalRuntimeDiagnostics.count(com.crypto.local.LocalRuntimeDiagnostics.Event.INPUT_FAILED_OR_UNCONFIRMED);throw failure;
        }
        // FIX-131: executeWithoutResult returned successfully: this is input COMMIT, not callback completion.
        try { com.crypto.client.binance.websocket.KlineReceipt.inputCommitted(symbol, interval, candleOpenTime, observedAt); }
        catch (RuntimeException diagnosticFailure) { log.warn("[FIX-131][RECEIPT_DIAGNOSTIC_FAILED] symbol={}", symbol, diagnosticFailure); }
        if (protect != null) {
            int attempts = 0;
            RuntimeException failure = null;
            do {
                attempts++;
                try {
                    timing.measure(context, "PROTECTION_TRANSACTION", false, () -> transaction.executeWithoutResult(tx -> protect.run()));
                    failure = null;
                    break;
                } catch (RuntimeException ex) {
                    failure = ex;
                    // FIX-153: completion returned/failed; a commit exception alone does not prove rollback.
                    // Never retry a late wallet/commit error or an unknown outcome.
                    if (!(ex instanceof InitialPositionLockDeadlock) || attempts == MAX_ATTEMPTS) break;
                    log.warn("[FIX-124][PRODUCTION][INITIAL_LOCK_RETRY] symbol={}, candleOpenTime={}, observedAt={}, attempt={}",
                            symbol, candleOpenTime, observedAt, attempts);
                }
            } while (attempts < MAX_ATTEMPTS);
            if (failure != null || attempts > 1) {
                String outcome = failure == null ? "RECOVERED" : "FAILED";
                if (failure == null) {
                    log.info("[FIX-124][PRODUCTION][RECOVERED] symbol={}, observedAt={}, attempts={}", symbol, observedAt, attempts);
                } else {
                    com.crypto.local.LocalRuntimeDiagnostics.count(com.crypto.local.LocalRuntimeDiagnostics.Event.PROTECTION_FAILED_OR_UNCONFIRMED);
                    log.error("[FIX-124][PRODUCTION][FAILED] symbol={}, observedAt={}, attempts={}; input committed; protection completion failed or unconfirmed, consult durable price evidence",
                            symbol, observedAt, attempts, failure);
                }
                diagnostics.record(symbol, interval, candleOpenTime, observedAt, price, attempts, outcome, failure);
            }
        }
        if (observe != null) {
            try {
                timing.measure(context, "OBSERVER_TRANSACTION", false, () -> transaction.executeWithoutResult(tx -> observe.run()));
            } catch (RuntimeException ex) {
                log.warn("[FIX-124][OBSERVER_FAILED] symbol={}; input committed; protection outcome remains in durable price evidence", symbol, ex);
            }
        }
        // AFTER_COMMIT listener still receives an actual committed transaction;
        // publishing outside a transaction would silently drop the analysis event.
        if (publishClosed != null) timing.measure(context, "CLOSE_DISPATCH_TRANSACTION", false,
                () -> transaction.executeWithoutResult(tx -> publishClosed.run()));
    }
}
