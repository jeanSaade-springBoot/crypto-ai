package com.crypto.indicator.event;

import com.crypto.domain.PaperPosition;
import com.crypto.domain.TechnicalIndicator;
import com.crypto.domain.TradeSignal;
import com.crypto.dto.CandleDataQualityResult;
import com.crypto.indicator.service.TechnicalIndicatorService;
import com.crypto.repository.TradeSignalRepository;
import com.crypto.service.AnalysisService;
import com.crypto.service.CandleDataQualityService;
import com.crypto.service.PaperTradingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * The exact production analysis work formerly embedded in CandleClosedEventListener.
 *
 * FIX-043 changes WHERE the work runs, not WHAT trading logic runs. Keeping the complete existing
 * pipeline in one worker makes that boundary explicit and prevents future performance changes from
 * accidentally duplicating/replacing scoring, veto, wake-up or execution rules.
 */
@Component
public class CandleClosedAnalysisWorker {
    @org.springframework.beans.factory.annotation.Autowired(required=false) private com.crypto.local.ExchangeClockSynchronizer exchangeClock;
    @org.springframework.beans.factory.annotation.Autowired(required=false) private com.crypto.local.CandleAnalysisOutcomeStore outcomes;
    // FIX-138 review: required evidence dependency is explicit in production and tests.
    private final org.springframework.jdbc.core.JdbcTemplate sharedWorkEvidence;


    private static final Logger log = LoggerFactory.getLogger(CandleClosedAnalysisWorker.class);

    private final TechnicalIndicatorService technicalIndicatorService;
    private final AnalysisService analysisService;
    private final PaperTradingService paperTradingService;
    private final CandleDataQualityService candleDataQualityService;
    private final TradeSignalRepository tradeSignalRepository;
    private final CandleAnalysisExecutionCoordinator executionCoordinator;

    public CandleClosedAnalysisWorker(
            TechnicalIndicatorService technicalIndicatorService,
            AnalysisService analysisService,
            PaperTradingService paperTradingService,
            CandleDataQualityService candleDataQualityService,
            TradeSignalRepository tradeSignalRepository,
            CandleAnalysisExecutionCoordinator executionCoordinator,
            org.springframework.jdbc.core.JdbcTemplate sharedWorkEvidence
    ) {
        this.technicalIndicatorService = technicalIndicatorService;
        this.analysisService = analysisService;
        this.paperTradingService = paperTradingService;
        this.candleDataQualityService = candleDataQualityService;
        this.tradeSignalRepository = tradeSignalRepository;
        this.executionCoordinator = executionCoordinator;
        this.sharedWorkEvidence = java.util.Objects.requireNonNull(sharedWorkEvidence, "sharedWorkEvidence");
    }

    private java.time.Instant referenceNow(){
        java.time.Instant local=java.time.Instant.now();
        return exchangeClock==null?local:exchangeClock.correctJvm(local);
    }

    // FIX-153: use persisted close authority; a queued candle can expire before analysis starts.
    public void process(CandleClosedEvent event) { processShared(event,event.closeTime(),true); }

    /** FIX-132 reports actual completion, never enqueue success. Historical-only
     * analysis may persist evidence but never registers or invokes wallet work. */
    public String processShared(CandleClosedEvent event, java.time.Instant closeTime, boolean liveSource) {
        return processShared(event,closeTime,liveSource,null);
    }

    /** FIX-132 event ownership is explicit, including across executor boundaries. */
    public String processShared(CandleClosedEvent event, java.time.Instant closeTime, boolean liveSource, Long sourceEventId) {
        // FIX-137: one correlated boundary around every legacy/shared worker attempt.
        long started = System.nanoTime();
        String outcome = "UNCONFIRMED";
        log.info("[FIX-137][WORKER_START] event={}, symbol={}, interval={}, open={}, close={}, liveSource={}",
                sourceEventId,event.symbol(),event.intervalCode(),event.openTime(),closeTime,liveSource);
        try {
            outcome = processSharedTraced(event,closeTime,liveSource,sourceEventId,started);
            return outcome;
        } finally {
            log.info("[FIX-137][WORKER_END] event={}, symbol={}, interval={}, open={}, outcome={}, elapsedMs={}",
                    sourceEventId,event.symbol(),event.intervalCode(),event.openTime(),outcome,
                    (System.nanoTime()-started)/1_000_000);
        }
    }

    private String processSharedTraced(CandleClosedEvent event, java.time.Instant closeTime,
            boolean liveSource, Long sourceEventId, long started) {
        // FIX-140: only explicitly attributed safe retries can resume an existing signal.
        // Generic REVIEW_REQUIRED rows and natural-key matches never authorize execution.
        if(sourceEventId!=null && liveSource) {
            var retry=sharedWorkEvidence.queryForList("SELECT signal_id FROM signal_processing_work WHERE source_event_id=? AND status='SYMBOL_LOCK_RETRY' AND failure_stage='INITIAL_SYMBOL_LOCK_ROLLED_BACK' AND next_attempt_at<=CURRENT_TIMESTAMP(6)",sourceEventId);
            if(retry.size()==1) {
                TradeSignal saved=tradeSignalRepository.findById(((Number)retry.getFirst().get("signal_id")).longValue()).orElseThrow();
                if(!event.symbol().equals(saved.getSymbol()) || !event.intervalCode().equals(saved.getInterval())
                    || !event.openTime().equals(saved.getCandleOpenTime()))return "REVIEW_REQUIRED";
                try {paperTradingService.processSharedSignal(saved,sourceEventId);}
                catch(com.crypto.execution.processing.SymbolLockRetryScheduled scheduled) {return processingOutcome(sourceEventId);}
                catch(Exception failure) {log.error("[FIX-140][RETRY_FAILED] event={}",sourceEventId,failure);return "REVIEW_REQUIRED";}
                return processingOutcome(sourceEventId);
            }
        }
        String stage = "COORDINATION_LOCK";
        traceStage(sourceEventId,event,stage,started);
        // FIX-074: serialize only the exact candle identity against FIX-043 recovery.
        // This removes the duplicate trade_signal race while preserving parallelism across
        // independent symbols/timeframes and does not alter scoring or execution semantics.
        try (CandleAnalysisExecutionCoordinator.LockHandle ignored = executionCoordinator.lock(
                event.symbol(), event.intervalCode(), event.openTime())) {
            log.info("Processing committed CandleClosedEvent: symbol={}, interval={}, openTime={}",
                    event.symbol(), event.intervalCode(), event.openTime());

            stage = "DATA_QUALITY";
            traceStage(sourceEventId,event,stage,started);
            CandleDataQualityResult dataQuality = candleDataQualityService.validate(
                    event.symbol(), event.intervalCode());
            if (!dataQuality.valid()) {
                log.warn(
                        "Automatic analysis blocked by candle data quality: symbol={}, interval={}, warnings={}",
                        event.symbol(), event.intervalCode(), dataQuality.warnings());
                return terminal(event,"SKIPPED_DATA_UNAVAILABLE","DATA_QUALITY_BLOCKED","DATA_QUALITY_BLOCKED");
            }

            stage = "INDICATORS";
            traceStage(sourceEventId,event,stage,started);
            Optional<TechnicalIndicator> indicatorResult = technicalIndicatorService.calculateAndPersist(
                    event.symbol(), event.intervalCode(), event.openTime());
            if (indicatorResult.isEmpty()) {
                log.info(
                        "Automatic analysis skipped: symbol={}, interval={}, openTime={}, reason=history/as-of candle unavailable",
                        event.symbol(), event.intervalCode(), event.openTime());
                return terminal(event,"SKIPPED_DATA_UNAVAILABLE","HISTORY_UNAVAILABLE","HISTORY_UNAVAILABLE");
            }

            TechnicalIndicator indicator = indicatorResult.get();
            stage = "EXISTING_SIGNAL_CHECK";
            traceStage(sourceEventId,event,stage,started);
            if (tradeSignalRepository.existsBySymbolAndIntervalAndCandleOpenTime(
                    indicator.getSymbol(), indicator.getIntervalCode(), indicator.getCandleOpenTime())) {
                log.info(
                        "Automatic analysis skipped: signal already exists for symbol={}, interval={}, candleOpenTime={}",
                        indicator.getSymbol(), indicator.getIntervalCode(), indicator.getCandleOpenTime());
                if(sourceEventId==null)return terminal(event,"SKIPPED_ALREADY_ANALYSED","SIGNAL_ALREADY_EXISTS","ALREADY_EXISTS");
                // FIX-138: an expired source is historical even when originally LIVE.
                // Never register/replay work for an already existing historical signal.
                if(!liveSource || (closeTime!=null && !com.crypto.shared.SharedEventPolicy.closeEligible(
                        event.intervalCode(),closeTime,referenceNow())))return terminal(event,"SKIPPED_ALREADY_ANALYSED","HISTORICAL_SIGNAL_EXISTS","HISTORICAL_ALREADY_EXISTS");
                // Existing signal is NOT processing completion. Only an attributed,
                // completed work row establishes a prior shared business outcome.
                Integer completed=sharedWorkEvidence.queryForObject("SELECT COUNT(*) FROM signal_processing_work w JOIN shared_market_event_delivery d ON d.source_event_id=w.source_event_id WHERE w.symbol=? AND w.interval_code=? AND w.candle_open_time=? AND w.status='COMPLETED' AND d.symbol=w.symbol AND d.interval_code=w.interval_code AND d.candle_open_time=w.candle_open_time",Integer.class,event.symbol(),event.intervalCode(),java.sql.Timestamp.from(event.openTime()));
                if(completed==0) log.warn("[FIX-137][EXISTING_SIGNAL_REVIEW] event={}, symbol={}, interval={}, open={}, reason=NO_MATCHING_COMPLETED_SHARED_WORK; this does not prove work is absent",
                        sourceEventId,event.symbol(),event.intervalCode(),event.openTime());
                return completed>0?"ALREADY_COMPLETED":"REVIEW_REQUIRED";
            }

            if (closeTime != null && (!liveSource || !com.crypto.shared.SharedEventPolicy.closeEligible(event.intervalCode(),closeTime,referenceNow()))) {
                stage = "HISTORICAL_SIGNAL";
                traceStage(sourceEventId,event,stage,started);
                TradeSignal historical = analysisService.analyzeRecovered(indicator,closeTime);
                logSaved(sourceEventId,event,historical,"HISTORY");
                return terminal(event,"HISTORICAL_ONLY","HISTORICAL_ANALYSIS", "HISTORICAL_ONLY");
            }
            stage = "LIVE_SIGNAL_AND_REGISTRATION";
            traceStage(sourceEventId,event,stage,started);
            TradeSignal signal = sourceEventId == null
                ? analysisService.analyzeForProcessing(indicator, com.crypto.execution.processing.ProcessingOrigin.WORKER)
                : analysisService.analyzeForProcessing(indicator, com.crypto.execution.processing.ProcessingOrigin.WORKER,sourceEventId);
            logSaved(sourceEventId,event,signal,"LIVE");
            stage = "SIGNAL_PROCESSING";
            traceStage(sourceEventId,event,stage,started);
            Optional<PaperPosition> position = sourceEventId == null ? paperTradingService.processSignal(signal)
                    : paperTradingService.processSharedSignal(signal,sourceEventId);

            log.info(
                    "Automatic candle flow completed: symbol={}, interval={}, openTime={}, score={}, decision={}, paperPositionOpened={}",
                    indicator.getSymbol(), indicator.getIntervalCode(), indicator.getCandleOpenTime(),
                    signal.getTotalScore(), signal.getDecision(), position.isPresent());
            // FIX-153: Optional.empty is not a completed/expired execution acknowledgment.
            return sourceEventId==null?localProcessingOutcome(signal.getId()):processingOutcome(sourceEventId);
        } catch (com.crypto.execution.processing.SymbolLockRetryScheduled scheduled) {
            return sourceEventId==null?"REVIEW_REQUIRED":processingOutcome(sourceEventId);
        } catch (Exception exception) {
            // FIX-043: never let one analysis failure kill the dispatcher lane. The next candle must
            // continue. FIX-132 LIVE persists this failure for reconciliation; legacy
            // recovery must not independently execute an uncertain shared outcome.
            log.error("[FIX-137][WORKER_STAGE_FAILED] event={}, symbol={}, interval={}, open={}, stage={}, elapsedMs={}",
                    sourceEventId,event.symbol(),event.intervalCode(),event.openTime(),stage,
                    (System.nanoTime()-started)/1_000_000,exception);
            log.error("Automatic candle flow failed for {} {} at {}",
                    event.symbol(), event.intervalCode(), event.openTime(), exception);
            if(sourceEventId != null) {
                try {
                    String detail=exception.getClass().getName()+": "+exception.getMessage();
                    sharedWorkEvidence.update("UPDATE shared_market_event_delivery SET last_error=? WHERE source_event_id=? AND analysis_status IN ('RUNNING','REVIEW_REQUIRED')",
                            detail.substring(0,Math.min(1000,detail.length())),sourceEventId);
                } catch(Exception recordingFailure) {
                    log.error("[FIX-136][ANALYSIS_ERROR_RECORD_FAILED] event={}",sourceEventId,recordingFailure);
                }
            }
            return "REVIEW_REQUIRED";
        }
    }
    /** FIX-138: emitted only after the transactional service proxy returned.
     * Signal persistence is distinct from wallet processing and delivery completion. */
    private static void logSaved(Long eventId,CandleClosedEvent event,TradeSignal signal,String mode) {
        if(signal==null || signal.getId()==null) {
            log.warn("[FIX-138][SIGNAL_SAVE_UNCONFIRMED] mode={}, event={}, symbol={}, interval={}; service returned no persisted signal identity",
                mode,eventId,event.symbol(),event.intervalCode());
            return;
        }
        java.time.Instant returned=java.time.Instant.now();
        Long liveDelayMs="LIVE".equals(mode)&&event.closeTime()!=null&&signal.getGeneratedAt()!=null
            ?java.time.Duration.between(event.closeTime(),signal.getGeneratedAt()).toMillis():null;
        Long insertionDelayMs="LIVE".equals(mode)&&event.closeTime()!=null&&signal.getCreatedAt()!=null
            ?java.time.Duration.between(event.closeTime(),signal.getCreatedAt()).toMillis():null;
        log.info("[FIX-153][SIGNAL_SAVED] mode={}, event={}, signal={}, symbol={}, interval={}, candleOpenUtc={}, candleCloseUtc={}, generatedUtc={}, rowCreatedUtc={}, serviceReturnedUtc={}, serviceReturnedKsa={}, liveCloseToGenerationMs={}, liveCloseToInsertionMs={}; rowCreatedUtc is row creation time, not database commit time; historical generatedUtc is an as-of clock, signal save does not imply a wallet trade",
            mode,eventId,signal.getId(),event.symbol(),event.intervalCode(),event.openTime(),event.closeTime(),signal.getGeneratedAt(),signal.getCreatedAt(),returned,returned.atOffset(java.time.ZoneOffset.ofHours(3)),liveDelayMs,insertionDelayMs);
    }
    private String localProcessingOutcome(Long signalId){
        if(signalId==null)return "PROCESSING_UNCONFIRMED";
        var statuses=sharedWorkEvidence.queryForList("SELECT status FROM signal_processing_work WHERE signal_id=?",String.class,signalId);
        if(statuses.size()!=1)return "PROCESSING_UNCONFIRMED";
        return switch(statuses.getFirst()){
            case "COMPLETED"->"COMPLETED";
            case "EXPIRED"->"EXECUTION_EXPIRED";
            default->"PROCESSING_UNCONFIRMED";
        };
    }
    /** FIX-140: Optional.empty is not proof of processing completion. */
    private String processingOutcome(long event) {
        var states=sharedWorkEvidence.queryForList("SELECT status FROM signal_processing_work WHERE source_event_id=?",event);
        if(states.size()!=1)return "REVIEW_REQUIRED";
        return switch(String.valueOf(states.getFirst().get("status"))) {
            case "COMPLETED"->"COMPLETED";
            case "EXPIRED"->"EXECUTION_EXPIRED";
            case "LOCK_RETRY_EXHAUSTED"->"EXECUTION_NOT_EXECUTED";
            case "SYMBOL_LOCK_RETRY"->"EXECUTION_RETRY";
            default->"REVIEW_REQUIRED";
        };
    }

    private static void traceStage(Long id, CandleClosedEvent event, String stage, long started) {
        log.info("[FIX-138][WORKER_STAGE] event={}, symbol={}, interval={}, open={}, stage={}, elapsedMs={}",
                id,event.symbol(),event.intervalCode(),event.openTime(),stage,
                (System.nanoTime()-started)/1_000_000);
    }
    private String terminal(CandleClosedEvent event,String outcome,String reason,String workerOutcome){
        if(outcomes!=null)outcomes.record(event.symbol(),event.intervalCode(),event.openTime(),outcome,reason,null,"CANDLE_WORKER");
        return workerOutcome;
    }

}
