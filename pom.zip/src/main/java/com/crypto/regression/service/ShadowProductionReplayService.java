package com.crypto.regression.service;

import com.crypto.domain.SignalDecision;
import com.crypto.domain.TradeSignal;
import com.crypto.position.service.PositionContinuationPolicy;
import com.crypto.position.service.NearTpFailureProtectionPolicy;
import com.crypto.position.service.NearTpState;
import com.crypto.position.service.PositionExitPolicy;
import com.crypto.position.service.ProfitLockPolicy;
import com.crypto.position.service.ProfitLockState;
import com.crypto.position.service.PositionPriceAuthorityPolicy;
import com.crypto.market.service.MarketPriceEventService;
import com.crypto.regression.replay.ReplayMinimumExecutionPolicy;
import com.crypto.regression.replay.ReplayBuyValidationPolicy;
import com.crypto.regression.replay.ReplayExecutionState;
import com.crypto.regression.replay.ReplayPolicyProfile;
import com.crypto.regression.replay.ReplayPolicyProfileStore;
import com.crypto.regression.replay.ReplayRunOutputStore;
import com.crypto.regression.replay.ReplayRunCertificateStore;
import com.crypto.regression.replay.ReplayDecisionTraceStore;
import com.crypto.regression.replay.ReplayAccessPolicy;
import com.crypto.regression.replay.ReplayPriceCoverageStore;
import com.crypto.regression.replay.ReplaySellValidationPolicy;
import com.crypto.regression.replay.ReplaySizingPolicy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Comparator;
import java.util.List;
import java.util.function.BooleanSupplier;

@Service
@RequiredArgsConstructor
@Slf4j
public class ShadowProductionReplayService {
    private static final MathContext MC = MathContext.DECIMAL64;
    private static final BigDecimal INITIAL_CAPITAL = BigDecimal.valueOf(10000);

    private final JdbcTemplate jdbcTemplate;
    private final ReplayBuyValidationPolicy replayBuyValidationPolicy;
    private final ReplayExecutionState replayScope;
    private final PositionContinuationPolicy continuationPolicy;
    private final PositionExitPolicy exitPolicy;
    private final ProfitLockPolicy profitLockPolicy;
    private final ReplaySellValidationPolicy replaySellValidationPolicy;
    private final ReplayPolicyProfileStore replayPolicyProfileStore;
    private final ReplayRunOutputStore replayRunOutputStore;
    private final ReplayRunCertificateStore replayRunCertificateStore;
    private final ReplayDecisionTraceStore replayDecisionTraceStore;
    private final ReplayPriceCoverageStore replayPriceCoverageStore;
    private final ReplaySizingPolicy replaySizingPolicy;
    private final ReplayMinimumExecutionPolicy replayMinimumExecutionPolicy;
    private final PositionPriceAuthorityPolicy priceAuthorityPolicy;
    private final NearTpFailureProtectionPolicy nearTpFailureProtectionPolicy;
    private final ThreadLocal<ReplayPolicyProfile> activeReplayProfile = new ThreadLocal<>();

    private static void requireReplayWrite(String table) {
        ReplayAccessPolicy.require(table, ReplayAccessPolicy.Operation.REPLAY_UPDATE);
    }

    public ReplayStats replay(long runId, String symbol, Instant executionStart, Instant executionEnd,
                              List<TradeSignal> generatedSignals,
                              List<MarketPriceEventService.PriceEvent> productionPriceEvents,
                              BooleanSupplier stopRequested) {
        // FIX-156: no wallet_settings fallback. A profile must be frozen before Replay starts.
        ReplayPolicyProfile replayProfile = replayPolicyProfileStore.require(runId);
        requireReplayWrite("replay_position");
        requireReplayWrite("replay_execution");
        requireReplayWrite("replay_position_management");
        activeReplayProfile.set(replayProfile);
        try {
        List<TradeSignal> timeline = generatedSignals.stream()
                .filter(s -> s != null && s.getGeneratedAt() != null)
                .sorted(Comparator.comparing(TradeSignal::getGeneratedAt)
                        .thenComparingInt(s -> intervalOrder(s.getInterval())))
                .toList();

        TradeSignal latest1m = null;
        TradeSignal latest5m = null;
        TradeSignal latest1h = null;
        ShadowPosition open = null;
        BigDecimal cash = INITIAL_CAPITAL;
        BigDecimal realized = BigDecimal.ZERO;
        int trades = 0, wins = 0, losses = 0;
        int consecutiveFinalOneMinuteStrongSells = 0;
        BigDecimal replayDailyBudget = replaySizingPolicy.initialDailyBudget(
                cash, replayProfile.minimumUsdtReserve(), replayProfile.baseTradeAmountUsdt(),
                replayProfile.maximumDailyNewPositions());
        LocalDate replayTradeDate = null;
        int replayExecutedNewPositions = 0;
        // FIX-052: when Production live-price events exist, Replay uses them as the
        // authoritative mechanical-protection clock. Older windows created before V64
        // transparently retain candle/signal-close fallback and are therefore not claimed
        // as tick-exact parity runs.
        List<MarketPriceEventService.PriceEvent> livePrices = productionPriceEvents == null
                ? List.of()
                : productionPriceEvents.stream()
                    .filter(e -> e != null && e.observedAt() != null && e.price() != null)
                    .sorted(Comparator.comparing(MarketPriceEventService.PriceEvent::observedAt))
                    .toList();
        boolean exactPriceReplay = !livePrices.isEmpty();
        int livePriceIndex = 0;
        // FIX-109: normal Regression/Replay runs are Production-Parity by default.
        // Experimental rules require an explicitly opened EXPERIMENTAL scope.
        String replayLogicMode = "PRODUCTION_PARITY";
        // FIX-156: legacy FIX-11K/FIX-11Q observers are excluded from baseline
        // parity execution. Their historical data/display code remains untouched.

        try (ReplayExecutionState.Scope ignored = replayScope.open(runId, timeline)) {
        // FIX-156 / RET-01: baseline Replay has one declared Production-parity
        // policy. It must not read the legacy shared FIX-122 experiment switch,
        // because that switch changes a historical decision with non-fixture data.
        replayScope.fix122Enabled(true);
        for (TradeSignal signal : timeline) {
            // FIX-090: shadow execution is frequently cancellable without affecting Production.
            if (stopRequested != null && stopRequested.getAsBoolean()) {
                throw new ReplayCancellationException(runId);
            }
            // FIX-052 exact ordering: BinanceKlineService invokes live position protection
            // from the 1m price update BEFORE publishing the candle-close analysis event.
            // Consume all persisted Production prices up to this signal timestamp before
            // making the freshly generated signal visible to position management.
            while (livePriceIndex < livePrices.size()
                    && (stopRequested == null || !stopRequested.getAsBoolean())
                    && !livePrices.get(livePriceIndex).observedAt().isAfter(signal.getGeneratedAt())) {
                MarketPriceEventService.PriceEvent live = livePrices.get(livePriceIndex++);
                replayScope.referencePrice(symbol, live.observedAt(), live.price());
                if (open != null && !live.observedAt().isBefore(executionStart) && !live.observedAt().isAfter(executionEnd)) {
                    LivePriceEvaluation protection = evaluateLivePrice(runId, symbol, open, live, latest1m, latest5m, latest1h);
                    open = protection.position();
                    if (protection.partialProceeds().signum() > 0) {
                        cash = cash.add(protection.partialProceeds(), MC);
                        realized = realized.add(protection.partialRealizedPnl(), MC);
                    }
                    ExitDecision liveExit = protection.decision();
                    if (liveExit.exit()) {
                        BigDecimal proceeds = live.price().multiply(open.quantity(), MC);
                        BigDecimal pnl = proceeds.subtract(open.cost(), MC);
                        BigDecimal pnlPct = percentage(open.entryPrice(), live.price());
                        BigDecimal totalPositionPnl = open.partialRealizedPnl().add(pnl, MC);
                        BigDecimal totalPositionPnlPct = totalPositionPnlPercent(open, pnl);
                        cash = cash.add(proceeds, MC);
                        realized = realized.add(pnl, MC);
                        trades++;
                        if (totalPositionPnl.signum() > 0) wins++; else if (totalPositionPnl.signum() < 0) losses++;
                        // replay_execution stores this terminal leg; replay_position stores
                        // the whole lifecycle including any earlier FIX-11T partial realization.
                        persistSellAtPrice(runId, symbol, live, latest1m, open, liveExit, pnl, pnlPct);
                        closePositionAtPrice(runId, open.positionId(), live, liveExit, totalPositionPnl, totalPositionPnlPct);
                        replayScope.recordStop(symbol, open.positionId(), live.observedAt(), liveExit.reason());
                                                open = null;
                    }
                }
            }

            replayScope.reference(signal.getGeneratedAt());
            if ("1m".equals(signal.getInterval())) {
                latest1m = signal;
                consecutiveFinalOneMinuteStrongSells = signal.getDecision() == SignalDecision.STRONG_SELL
                        ? consecutiveFinalOneMinuteStrongSells + 1 : 0;
            }
            if ("5m".equals(signal.getInterval())) latest5m = signal;
            if ("1h".equals(signal.getInterval())) latest1h = signal;

            if (open != null && !exactPriceReplay) {
                // Pre-V64 fallback only. Exact-parity runs receive mechanical protection from
                // the persisted Production live-price stream above.
                ExitDecision exit = evaluateExit(runId, open, signal, latest1m, latest5m, latest1h);
                if (exit.exit()) {
                    BigDecimal proceeds = signal.getLatestPrice().multiply(open.quantity(), MC);
                    BigDecimal pnl = proceeds.subtract(open.cost(), MC);
                    BigDecimal pnlPct = percentage(open.entryPrice(), signal.getLatestPrice());
                    BigDecimal totalPositionPnl = open.partialRealizedPnl().add(pnl, MC);
                    BigDecimal totalPositionPnlPct = totalPositionPnlPercent(open, pnl);
                    cash = cash.add(proceeds, MC);
                    realized = realized.add(pnl, MC);
                    trades++;
                    if (totalPositionPnl.signum() > 0) wins++; else if (totalPositionPnl.signum() < 0) losses++;
                    persistSell(runId, symbol, signal, open, exit, pnl, pnlPct);
                    closePosition(runId, open.positionId(), signal, exit, totalPositionPnl, totalPositionPnlPct);
                    // FIX-020 replay parity: a terminal replay exit consumes the same
                    // opportunity evidence boundary as production before any new BUY can form.
                    replayScope.recordStop(symbol, open.positionId(), signal.getGeneratedAt(), exit.reason());
                                        open = null;
                    // Production PaperTradingService returns immediately after a signal-driven
                    // terminal close; it cannot reopen from that same signal invocation.
                    continue;
                } else {
                    if (exit.newTakeProfit() != null) {
                        open = rebaseForExtendedTarget(open, exit.newTakeProfit(), signal.getLatestPrice(), signal.getGeneratedAt())
                                .withTakeProfit(exit.newTakeProfit());
                        persistProfitLockState(open);
                        persistNearTpState(open);
                    }
                    open = updateProfitLock(open, signal);
                    // FIX-11T: legacy signal-price fallback cannot be tick-exact, but it still
                    // executes the SAME Near-TP policy from the authoritative historical signal
                    // price so older Replay windows do not silently omit the Production rule.
                    if (priceAuthorityPolicy.canUseSignalPrice(signal, open.entryTime())) {
                        FallbackNearTpEvaluation nearTpFallback = evaluateNearTpAtSignalFallback(
                                runId, open, signal, latest1m, latest5m);
                        open = nearTpFallback.position();
                        if (nearTpFallback.partialProceeds().signum() > 0) {
                            cash = cash.add(nearTpFallback.partialProceeds(), MC);
                            realized = realized.add(nearTpFallback.partialRealizedPnl(), MC);
                        }
                    }
                    persistManagement(runId, signal, open.profitLockActive() ? "PROFIT_LOCK_ACTIVE" : "POSITION_HOLD",
                            open.takeProfit(), open.takeProfit(), open, exit.explanation());
                }
            }

            if (open != null && exactPriceReplay && "1m".equals(signal.getInterval()) && bearish(signal.getDecision())) {
                // Production's candle-close PaperTradingService has one additional SELL authority
                // after live-price protection: validate the newly generated 1m bearish signal.
                ReplaySellValidationPolicy.Result validatedSell = replaySellValidationPolicy.validate(signal, latest5m, latest1h);
                if (validatedSell.allowed()) {
                    ExitDecision exit = new ExitDecision(true, validatedSell.code(), validatedSell.explanation());
                    BigDecimal proceeds = signal.getLatestPrice().multiply(open.quantity(), MC);
                    BigDecimal pnl = proceeds.subtract(open.cost(), MC);
                    BigDecimal pnlPct = percentage(open.entryPrice(), signal.getLatestPrice());
                    BigDecimal totalPositionPnl = open.partialRealizedPnl().add(pnl, MC);
                    BigDecimal totalPositionPnlPct = totalPositionPnlPercent(open, pnl);
                    cash = cash.add(proceeds, MC);
                    realized = realized.add(pnl, MC);
                    trades++;
                    if (totalPositionPnl.signum() > 0) wins++; else if (totalPositionPnl.signum() < 0) losses++;
                    persistSell(runId, symbol, signal, open, exit, pnl, pnlPct);
                    closePosition(runId, open.positionId(), signal, exit, totalPositionPnl, totalPositionPnlPct);
                    replayScope.recordStop(symbol, open.positionId(), signal.getGeneratedAt(), exit.reason());
                                        open = null;
                    // Same production invocation cannot both SELL and immediately BUY again.
                    continue;
                }
            }

            // FIX-014 replay parity: production may use a fresh 5m BUY transition only to
            // wake an already-live deferred 1m opportunity. The actual execution/risk plan
            // remains the latest fresh 1m signal returned by the shared production service.
            // All other non-1m signals remain context-only exactly as before.
            TradeSignal executionSignal = signal;
            ReplayBuyValidationPolicy.Result decision;
            if (!"1m".equals(signal.getInterval())) {
                continue;
            }
            int currentAllocation = open == null ? 0 : open.positionPercent();
            decision = replayBuyValidationPolicy.evaluate(signal, currentAllocation, replayProfile);
            replayDecisionTraceStore.recordBuyDecision(runId, signal.getId(), signal.getGeneratedAt(), decision);

            // Warm-up evaluates the SAME production decision service so evidence/opportunity
            // memory is realistic at executionStart, but it never opens or adds to a wallet
            // position before the requested test window. The trigger timestamp (signal) controls
            // the replay window; executionSignal owns price/risk just like production.
            boolean inExecutionWindow = !signal.getGeneratedAt().isBefore(executionStart)
                    && !signal.getGeneratedAt().isAfter(executionEnd);
            LocalDate signalTradeDate = signal.getGeneratedAt().atZone(ZoneOffset.UTC).toLocalDate();
            if (!signalTradeDate.equals(replayTradeDate)) {
                replayTradeDate = signalTradeDate;
                replayExecutedNewPositions = 0;
                replayDailyBudget = replaySizingPolicy.initialDailyBudget(
                        cash, replayProfile.minimumUsdtReserve(), replayProfile.baseTradeAmountUsdt(),
                        replayProfile.maximumDailyNewPositions());
            }
            // FIX-156: baseline BUY admission is Replay-local and consumes only the
            // frozen profile plus the selected historical signal evidence.
            if (!inExecutionWindow) continue;

            if (open == null && decision.allowed()) {
                // FIX-056 Replay parity: resolve the same canonical execution-price authority
                // after the same Production decision gates, then revalidate Entry Quality at
                // that price before sizing. A replay without a fresh price event cannot claim
                // exact execution parity and therefore does not open the position here.
                ReplayExecutionPrice fresh = resolveReplayPrice(livePrices, signal.getGeneratedAt());
                if (fresh == null) continue;
                int atrPercent = executionSignal.getAtrRecommendedPositionPercent() <= 0 ? 100 : executionSignal.getAtrRecommendedPositionPercent();
                int effectivePercent = Math.max(1, Math.min(100,
                        (int)Math.round(atrPercent * decision.positionPercent() / 100.0)));
                ReplaySizingPolicy.Plan sizing = replaySizingPolicy.plan(
                        cash, replayProfile.minimumUsdtReserve(), replayDailyBudget,
                        effectivePercent, 0, true, replayProfile.maximumDailyNewPositions(),
                        replayExecutedNewPositions, fresh.price());
                BigDecimal budget = sizing.spend();
                if (sizing.allowed()) {
                    BigDecimal qty = sizing.quantity();
                    effectivePercent = sizing.normalizedPositionPercent();
                    long positionId = openPosition(runId, symbol, executionSignal, fresh, qty, budget, effectivePercent);
                    persistBuy(runId, symbol, executionSignal, fresh, qty, budget, effectivePercent, decision);
                    cash = cash.subtract(budget, MC);
                    replayExecutedNewPositions++;
                    // Keep the complete immutable BUY thesis needed by production continuation.
                    // Replay must not drop entry structure and silently evaluate a different exit policy.
                    open = new ShadowPosition(positionId, executionSignal.getGeneratedAt(), fresh.price(), qty, budget,
                            effectivePercent, executionSignal.getStopLoss(), executionSignal.getTakeProfit(), fresh.price(), false, null,
                            ProfitLockState.INACTIVE, null,
                            executionSignal.getTotalScore(), executionSignal.getConfidenceScore(), executionSignal.getTrendScore(), executionSignal.getTrendStructureScore(),
                            executionSignal.getMomentumScore(), executionSignal.getVolumeScore(),
                            NearTpState.INACTIVE, null, 0, null, false, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);
                    // FIX-112A: only an actually opened shadow position consumes the bullish entry.
                    replayScope.markEntryConsumed(executionSignal.getId());
                }
            } else if (open != null && decision.allowed()) {
                // FIX-056: progressive Replay adds use the same fresh execution price and
                // execution-time Entry Quality revalidation as Production.
                ReplayExecutionPrice fresh = resolveReplayPrice(livePrices, signal.getGeneratedAt());
                if (fresh == null) continue;
                int addPercent = Math.max(1, Math.min(100 - open.positionPercent(), decision.positionPercent()));
                ReplaySizingPolicy.Plan sizing = replaySizingPolicy.plan(
                        cash, replayProfile.minimumUsdtReserve(), replayDailyBudget,
                        addPercent, open.positionPercent(), false, replayProfile.maximumDailyNewPositions(),
                        replayExecutedNewPositions, fresh.price());
                BigDecimal budget = sizing.spend();
                if (sizing.allowed()) {
                    addPercent = sizing.normalizedPositionPercent();
                    BigDecimal addedQty = sizing.quantity();
                    persistBuy(runId, symbol, signal, fresh, addedQty, budget, addPercent, decision);
                    // FIX-112A: a progressive add consumes only its own triggering signal.
                    replayScope.markEntryConsumed(signal.getId());
                    cash = cash.subtract(budget, MC);
                    open = addToPosition(runId, open, signal, addedQty, budget, addPercent);
                }
            }
        }
        }

        BigDecimal finalWallet = cash;
        if (open != null && !timeline.isEmpty()) {
            BigDecimal mark = timeline.get(timeline.size() - 1).getLatestPrice();
            if (mark != null) finalWallet = finalWallet.add(mark.multiply(open.quantity(), MC), MC);
        }

        jdbcTemplate.update("""
                UPDATE analysis_test_run
                SET simulated_trade_count=?, simulated_win_count=?, simulated_loss_count=?,
                    simulated_realized_pnl=?, simulated_final_wallet=?
                WHERE id=?
                """, trades, wins, losses, realized, finalWallet, runId);
        // FIX-109: expose whether this run had the persisted live-price stream required
        // for tick-exact production ordering. Older windows remain explicitly labelled
        // as fallback instead of being mistaken for exact parity.
        String priceReplayMode = exactPriceReplay ? "EXACT_PRICE_REPLAY" : "SIGNAL_PRICE_FALLBACK";
        replayRunOutputStore.recordExecutionSummary(runId, trades, wins, losses, realized,
                finalWallet, priceReplayMode, replayLogicMode);
        ReplayPriceCoverageStore.Coverage coverage = replayPriceCoverageStore.record(
                runId, symbol, executionStart, executionEnd, livePrices);
        replayRunCertificateStore.recordNotMeasured(runId, replayProfile,
                coverage.qualified() ? "QUALIFIED_PRICE_COVERAGE_BUT_PRODUCTION_COMPARISON_NOT_AVAILABLE"
                        : "QUALIFIED_PRICE_COVERAGE_NOT_AVAILABLE");
        return new ReplayStats(trades, wins, losses, realized, finalWallet, priceReplayMode, replayLogicMode);
        } finally {
            activeReplayProfile.remove();
        }
    }

    /**
     * FIX-052: mechanical position protection evaluated from the exact Production
     * 1m live-price observation stream. The order mirrors LivePositionProtectionService:
     * TAKE_PROFIT -> STOP_LOSS -> PROFIT_LOCK -> normal HTF exit. The newly closed
     * 1m signal is intentionally not visible yet; BinanceKlineService calls onPrice()
     * before publishing the candle-close event in Production.
     */
    private LivePriceEvaluation evaluateLivePrice(long runId, String symbol, ShadowPosition p,
                                                   MarketPriceEventService.PriceEvent event,
                                                   TradeSignal oneMinute, TradeSignal five, TradeSignal one) {
        BigDecimal price = event.price();
        ShadowPosition current = p;

        if (current.takeProfit() != null && price.compareTo(current.takeProfit()) >= 0) {
            PositionContinuationPolicy.Evaluation continuation = continuationPolicy.evaluate(
                    oneMinute, five, one,
                    current.entryTrend(), current.entryStructure(), current.entryMomentum(), current.entryVolume(),
                    current.entryConfidence(), current.entryScore());
            if (continuation.extendTarget()) {
                BigDecimal distance = current.takeProfit().subtract(current.entryPrice());
                BigDecimal oldTarget = current.takeProfit();
                BigDecimal newTarget = oldTarget.add(distance.multiply(BigDecimal.valueOf(0.50), MC), MC);
                ProfitLockState beforeState = current.profitLockState();
                current = rebaseForExtendedTarget(current, newTarget, price, event.observedAt()).withTakeProfit(newTarget);
                BigDecimal fix118NewProgress = progressPercent(current.entryPrice(), newTarget, current.highest());
                log.info("[FIX-118][REPLAY][TP_EXTENSION] runId={}, positionId={}, symbol={}, observedAt={}, marketPrice={}, " +
                                "entry={}, oldTp={}, newTp={}, highest={}, profitLockActive={}, profitLockPrice={}, previousState={}, state={}, " +
                                "newGeometryProgressPct={}",
                        runId, current.positionId(), symbol, event.observedAt(), price, current.entryPrice(), oldTarget, newTarget,
                        current.highest(), current.profitLockActive(), current.profitLockPrice(), beforeState, current.profitLockState(), fix118NewProgress);
                jdbcTemplate.update("UPDATE replay_position SET take_profit_usdt=? WHERE id=?", newTarget, current.positionId());
                persistProfitLockState(current);
                persistNearTpState(current);
                persistManagementAtPrice(runId, symbol, event, "TAKE_PROFIT_EXTENDED", oldTarget, newTarget, current, continuation.explanation());
                return new LivePriceEvaluation(ExitDecision.hold(), current);
            }
            // FIX-11Q: baseline continuation has already failed. Only now may the replay-only
            // counterfactual evaluate the one-candle grace. Existing PASS/TP-extension behavior above
            // always wins first and is never intercepted by this experiment.
            persistManagementAtPrice(runId, symbol, event, "TAKE_PROFIT_EXIT", current.takeProfit(), current.takeProfit(), current, continuation.explanation());
            return new LivePriceEvaluation(new ExitDecision(true, "TAKE_PROFIT", continuation.explanation()), current);
        }

        // Production stop-loss has priority over profit-lock evaluation.
        if (current.stopLoss() != null && price.compareTo(current.stopLoss()) <= 0) {
            return new LivePriceEvaluation(new ExitDecision(true, "STOP_LOSS",
                    "Live price " + price + " reached stop loss " + current.stopLoss()), current);
        }

        ShadowPosition updated = profitLockState(current, price);
        if (!equalsNullable(current.highest(), updated.highest())
                || current.profitLockActive() != updated.profitLockActive()
                || !equalsNullable(current.profitLockPrice(), updated.profitLockPrice())
                || current.profitLockState() != updated.profitLockState()
                || !java.util.Objects.equals(current.profitLockRebaseStartedAt(), updated.profitLockRebaseStartedAt())) {
            jdbcTemplate.update("UPDATE replay_position SET highest_price_usdt=?, profit_lock_active=?, profit_lock_price_usdt=?, profit_lock_state=?, profit_lock_rebase_started_at=? WHERE id=?",
                    updated.highest(), updated.profitLockActive(), updated.profitLockPrice(), updated.profitLockState().name(),
                    updated.profitLockRebaseStartedAt() == null ? null : Timestamp.from(updated.profitLockRebaseStartedAt()), updated.positionId());
        }
        if (updated.profitLockState() == ProfitLockState.ACTIVE
                || updated.profitLockState() == ProfitLockState.TP_EXTENSION_REBASE
                || !equalsNullable(current.highest(), updated.highest())
                || current.profitLockActive() != updated.profitLockActive()
                || !equalsNullable(current.profitLockPrice(), updated.profitLockPrice())
                || current.profitLockState() != updated.profitLockState()) {
            BigDecimal fix118Progress = updated.takeProfit() == null || updated.takeProfit().compareTo(updated.entryPrice()) <= 0
                    ? BigDecimal.ZERO
                    : updated.highest().subtract(updated.entryPrice(), MC)
                            .multiply(BigDecimal.valueOf(100), MC)
                            .divide(updated.takeProfit().subtract(updated.entryPrice(), MC), 6, RoundingMode.HALF_UP);
            log.info("[FIX-118][REPLAY][LIVE_PATH] runId={}, positionId={}, symbol={}, observedAt={}, price={}, entry={}, target={}, " +
                            "highest={}, previousActive={}, active={}, previousState={}, state={}, previousLock={}, lock={}, progressPct={}, triggered={}",
                    runId, updated.positionId(), symbol, event.observedAt(), price, updated.entryPrice(), updated.takeProfit(),
                    updated.highest(), current.profitLockActive(), updated.profitLockActive(), current.profitLockState(), updated.profitLockState(),
                    current.profitLockPrice(), updated.profitLockPrice(), fix118Progress,
                    updated.profitLockState() == ProfitLockState.ACTIVE && updated.profitLockPrice() != null
                            && price.compareTo(updated.profitLockPrice()) <= 0);
        }
        current = updated;

        BigDecimal rebaseHardFloor = current.entryPrice().multiply(BigDecimal.valueOf(1.0005), MC);
        if (current.profitLockState() == ProfitLockState.TP_EXTENSION_REBASE
                && price.compareTo(rebaseHardFloor) < 0) {
            String reason = "TP-extension rebase safety floor was breached at " + rebaseHardFloor + ". " + profitLockConfigText();
            log.info("[FIX-118][REPLAY][REBASE_HARD_FLOOR] runId={}, positionId={}, symbol={}, observedAt={}, price={}, floor={}, target={}",
                    runId, current.positionId(), symbol, event.observedAt(), price, rebaseHardFloor, current.takeProfit());
            persistManagementAtPrice(runId, symbol, event, "PROFIT_LOCK_HARD_EXIT", current.takeProfit(), current.takeProfit(), current, reason);
            return new LivePriceEvaluation(new ExitDecision(true, "PROFIT_LOCK_HARD_EXIT", reason), current);
        }

        if (current.profitLockState() == ProfitLockState.ACTIVE && current.profitLockPrice() != null
                && price.compareTo(current.profitLockPrice()) <= 0) {
            log.info("[FIX-118][REPLAY][LIVE_TRIGGER] runId={}, positionId={}, symbol={}, observedAt={}, price={}, lock={}, target={}",
                    runId, current.positionId(), symbol, event.observedAt(), price, current.profitLockPrice(), current.takeProfit());
            BigDecimal hardProfitFloor = current.entryPrice().multiply(BigDecimal.valueOf(1.0005), MC);
            if (price.compareTo(hardProfitFloor) < 0) {
                String reason = "Profit-lock hard floor was breached; protected profit can no longer be preserved. "
                        + profitLockConfigText();
                persistManagementAtPrice(runId, symbol, event, "PROFIT_LOCK_HARD_EXIT", current.takeProfit(), current.takeProfit(), current, reason);
                return new LivePriceEvaluation(new ExitDecision(true, "PROFIT_LOCK_HARD_EXIT", reason), current);
            }
            PositionExitPolicy.Evaluation lockDecision = exitPolicy.evaluateProfitLockBreach(oneMinute, five, one);
            if (lockDecision.exit()) {
                String reason = "Price retraced to the protected profit level after a profitable advance. "
                        + lockDecision.explanation() + " " + profitLockConfigText();
                persistManagementAtPrice(runId, symbol, event, "PROFIT_LOCK_EXIT", current.takeProfit(), current.takeProfit(), current, reason);
                return new LivePriceEvaluation(new ExitDecision(true, lockDecision.code(), reason), current);
            }
            persistManagementAtPrice(runId, symbol, event, "PROFIT_LOCK_HOLD", current.takeProfit(), current.takeProfit(), current,
                    lockDecision.explanation() + " " + profitLockConfigText());
        }

        PositionExitPolicy.Evaluation normalExit = exitPolicy.evaluateNormalExit(oneMinute, five, one);
        if (normalExit.exit()) {
            return new LivePriceEvaluation(new ExitDecision(true, normalExit.code(), normalExit.explanation()), current);
        }

        // FIX-11T: shared Production/Replay rule, evaluated LAST after all existing exits.
        NearTpFailureProtectionPolicy.State nearTpState = new NearTpFailureProtectionPolicy.State(
                current.nearTpState(), current.nearTpBestPrice(), current.nearTpBearishStreak(),
                current.nearTpLastOneMinuteSignalId(), current.nearTpHarvestUsed());
        NearTpFailureProtectionPolicy.Evaluation nearTp = nearTpFailureProtectionPolicy.evaluate(
                nearTpState, current.entryPrice(), current.takeProfit(), price, event.observedAt(), oneMinute, five);
        ShadowPosition nearTpUpdated = current.withNearTp(nearTp.state());
        if (!nearTpUpdated.sameNearTp(current)) {
            persistNearTpState(nearTpUpdated);
        }
        current = nearTpUpdated;
        if (nearTp.transition()) {
            log.info("FIX-11T Replay Near-TP: runId={}, positionId={}, symbol={}, code={}, state={}, price={}, best={}, givebackPct={}, bearish1mStreak={}, detail={}",
                    runId, current.positionId(), symbol, nearTp.code(), current.nearTpState(), price,
                    current.nearTpBestPrice(), nearTp.givebackPercent(), current.nearTpBearishStreak(), nearTp.explanation());
        }
        if (nearTp.harvestEligible()) {
            BigDecimal soldQty = current.quantity().multiply(BigDecimal.valueOf(0.50), MC);
            ReplayMinimumExecutionPolicy.Evaluation minimumCheck =
                    replayMinimumExecutionPolicy.evaluate(profile().minimumExecutableNotionalUsdt(), soldQty, price);
            if (!minimumCheck.executable()) {
                // Same as Production: a below-minimum Binance order is not simulated. Reset
                // to rejection monitoring and let all existing management continue unchanged.
                current = current.withNearTp(new NearTpFailureProtectionPolicy.State(
                        NearTpState.NEAR_TP_REJECTION_DETECTED, current.nearTpBestPrice(),
                        0, current.nearTpLastOneMinuteSignalId(), false));
                persistNearTpState(current);
                log.info("FIX-11T Replay NEAR_TP_HARVEST_SKIPPED: runId={}, positionId={}, symbol={}, reason={}, requestedQty={}, requestedNotional={}, binanceMinimum={}; existing position management continues",
                        runId, current.positionId(), symbol, minimumCheck.code(), soldQty,
                        minimumCheck.requestedNotional(), minimumCheck.minimumNotional());
                return new LivePriceEvaluation(ExitDecision.hold(), current);
            }
            BigDecimal proceeds = soldQty.multiply(price, MC);
            BigDecimal soldCost = current.entryPrice().multiply(soldQty, MC);
            BigDecimal partialPnl = proceeds.subtract(soldCost, MC);
            BigDecimal partialPct = soldCost.signum() == 0 ? BigDecimal.ZERO : partialPnl
                    .divide(soldCost, 8, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
            current = current.withPartialHarvest(soldQty, soldCost, partialPnl);
            persistNearTpPartialHarvest(runId, symbol, event, oneMinute, current, soldQty, proceeds, partialPnl, partialPct, nearTp.explanation());
            log.info("FIX-11T Replay NEAR_TP_PARTIAL_HARVESTED: runId={}, positionId={}, symbol={}, soldQty={}, remainingQty={}, price={}, partialPnl={}",
                    runId, current.positionId(), symbol, soldQty, current.quantity(), price, partialPnl);
            return new LivePriceEvaluation(ExitDecision.hold(), current, proceeds, partialPnl);
        }
        return new LivePriceEvaluation(ExitDecision.hold(), current);
    }

    private ExitDecision evaluateExit(long runId, ShadowPosition p, TradeSignal s, TradeSignal oneMinute, TradeSignal five, TradeSignal one) {
        BigDecimal price = s.getLatestPrice();
        if (price == null) return ExitDecision.hold();

        // Replay uses the exact same temporal price-authority rule as production. A signal
        // generated later may still carry a candle close from before entry; that historical
        // price may update MTF context but may not retroactively hit TP/SL/profit-lock.
        boolean authoritativePrice = priceAuthorityPolicy.canUseSignalPrice(s, p.entryTime());
        if (authoritativePrice && p.takeProfit() != null && price.compareTo(p.takeProfit()) >= 0) {
            // Exact production TP-continuation call, including immutable entry structure.
            // FIX-011 regression relies on Replay and live using this same shared policy.
            PositionContinuationPolicy.Evaluation continuation = continuationPolicy.evaluate(
                    oneMinute != null ? oneMinute : s, five, one,
                    p.entryTrend(), p.entryStructure(), p.entryMomentum(), p.entryVolume(),
                    p.entryConfidence(), p.entryScore());
            if (continuation.extendTarget()) {
                BigDecimal distance = p.takeProfit().subtract(p.entryPrice());
                BigDecimal newTarget = p.takeProfit().add(distance.multiply(BigDecimal.valueOf(0.50), MC), MC);
                persistManagement(runId, s, "TAKE_PROFIT_EXTENDED", p.takeProfit(), newTarget, p, continuation.explanation());
                jdbcTemplate.update("UPDATE replay_position SET take_profit_usdt=? WHERE id=?", newTarget, p.positionId());
                return new ExitDecision(false, "EXTEND_TAKE_PROFIT", continuation.explanation(), newTarget);
            }
            persistManagement(runId, s, "TAKE_PROFIT_EXIT", p.takeProfit(), p.takeProfit(), p, continuation.explanation());
            return new ExitDecision(true, "TAKE_PROFIT", continuation.explanation());
        }
        // FIX-052 fallback ordering also mirrors Production: STOP_LOSS is absolute and
        // is evaluated before profit-lock. Exact V64 runs normally take this path from
        // persisted live-price events rather than from signal-carried prices.
        if (authoritativePrice && p.stopLoss() != null && price.compareTo(p.stopLoss()) <= 0)
            return new ExitDecision(true, "STOP_LOSS", "Price reached the stored stop loss.");

        ShadowPosition updated = authoritativePrice ? profitLockState(p, price) : p;
        if (authoritativePrice && (updated.profitLockState() == ProfitLockState.ACTIVE
                || updated.profitLockState() == ProfitLockState.TP_EXTENSION_REBASE
                || p.profitLockActive() != updated.profitLockActive()
                || !equalsNullable(p.profitLockPrice(), updated.profitLockPrice())
                || p.profitLockState() != updated.profitLockState())) {
            BigDecimal fix118Progress = updated.takeProfit() == null || updated.takeProfit().compareTo(updated.entryPrice()) <= 0
                    ? BigDecimal.ZERO
                    : updated.highest().subtract(updated.entryPrice(), MC)
                            .multiply(BigDecimal.valueOf(100), MC)
                            .divide(updated.takeProfit().subtract(updated.entryPrice(), MC), 6, RoundingMode.HALF_UP);
            log.info("[FIX-118][REPLAY][SIGNAL_PATH] runId={}, positionId={}, signalId={}, symbol={}, generatedAt={}, price={}, " +
                            "entry={}, target={}, highest={}, previousActive={}, active={}, previousState={}, state={}, previousLock={}, lock={}, progressPct={}, triggered={}",
                    runId, updated.positionId(), s.getId(), s.getSymbol(), s.getGeneratedAt(), price,
                    updated.entryPrice(), updated.takeProfit(), updated.highest(), p.profitLockActive(), updated.profitLockActive(),
                    p.profitLockState(), updated.profitLockState(), p.profitLockPrice(), updated.profitLockPrice(), fix118Progress,
                    updated.profitLockState() == ProfitLockState.ACTIVE && updated.profitLockPrice() != null
                            && price.compareTo(updated.profitLockPrice()) <= 0);
        }
        BigDecimal minimumProfitableExit = p.entryPrice().multiply(BigDecimal.valueOf(1.0005));
        if (authoritativePrice && updated.profitLockState() == ProfitLockState.TP_EXTENSION_REBASE
                && price.compareTo(minimumProfitableExit) < 0) {
            String floorReason = "TP-extension rebase safety floor was breached at " + minimumProfitableExit + ". "
                    + profitLockConfigText();
            log.info("[FIX-118][REPLAY][SIGNAL_REBASE_HARD_FLOOR] runId={}, positionId={}, signalId={}, symbol={}, generatedAt={}, price={}, floor={}",
                    runId, updated.positionId(), s.getId(), s.getSymbol(), s.getGeneratedAt(), price, minimumProfitableExit);
            persistManagement(runId, s, "PROFIT_LOCK_HARD_EXIT", p.takeProfit(), p.takeProfit(), updated, floorReason);
            return new ExitDecision(true, "PROFIT_LOCK_HARD_EXIT", floorReason);
        }
        if (authoritativePrice && updated.profitLockState() == ProfitLockState.ACTIVE && updated.profitLockPrice() != null
                && price.compareTo(updated.profitLockPrice()) <= 0) {
            log.info("[FIX-118][REPLAY][SIGNAL_TRIGGER] runId={}, positionId={}, signalId={}, symbol={}, generatedAt={}, price={}, lock={}, target={}",
                    runId, updated.positionId(), s.getId(), s.getSymbol(), s.getGeneratedAt(), price,
                    updated.profitLockPrice(), updated.takeProfit());
            if (price.compareTo(minimumProfitableExit) < 0) {
                String floorReason = "Profit-lock hard floor was breached; protected profit can no longer be preserved. "
                        + profitLockConfigText();
                persistManagement(runId, s, "PROFIT_LOCK_HARD_EXIT", p.takeProfit(), p.takeProfit(), updated, floorReason);
                return new ExitDecision(true, "PROFIT_LOCK_HARD_EXIT", floorReason);
            }
            PositionExitPolicy.Evaluation lockDecision = exitPolicy.evaluateProfitLockBreach(
                    oneMinute != null ? oneMinute : s, five, one);
            if (!lockDecision.exit()) {
                String holdReason = lockDecision.explanation() + " " + profitLockConfigText();
                persistManagement(runId, s, "PROFIT_LOCK_HOLD", p.takeProfit(), p.takeProfit(), updated, holdReason);
                return ExitDecision.hold();
            }
            String lockReason = "Price retraced to the protected profit level after a profitable advance. "
                    + lockDecision.explanation() + " " + profitLockConfigText();
            persistManagement(runId, s, "PROFIT_LOCK_EXIT", p.takeProfit(), p.takeProfit(), updated, lockReason);
            return new ExitDecision(true, lockDecision.code(), lockReason);
        }
        // Production has two SELL authorities: the live HTF PositionExitPolicy and the
        // 1m signal TradeExecutionValidationService. Replay executes both shared production
        // policies in the same order instead of carrying a test-only SELL rule.
        PositionExitPolicy.Evaluation normalExit = exitPolicy.evaluateNormalExit(
                oneMinute != null ? oneMinute : s, five, one);
        if (normalExit.exit()) {
            return new ExitDecision(true, normalExit.code(), normalExit.explanation());
        }
        if ("1m".equals(s.getInterval()) && bearish(s.getDecision())) {
            ReplaySellValidationPolicy.Result validatedSell = replaySellValidationPolicy.validate(s, five, one);
            if (validatedSell.allowed()) {
                return new ExitDecision(true, validatedSell.code(), validatedSell.explanation());
            }
        }
        return ExitDecision.hold();
    }

    private FallbackNearTpEvaluation evaluateNearTpAtSignalFallback(long runId, ShadowPosition current,
                                                                    TradeSignal signal, TradeSignal oneMinute,
                                                                    TradeSignal fiveMinute) {
        NearTpFailureProtectionPolicy.State state = new NearTpFailureProtectionPolicy.State(
                current.nearTpState(), current.nearTpBestPrice(), current.nearTpBearishStreak(),
                current.nearTpLastOneMinuteSignalId(), current.nearTpHarvestUsed());
        NearTpFailureProtectionPolicy.Evaluation evaluation = nearTpFailureProtectionPolicy.evaluate(
                state, current.entryPrice(), current.takeProfit(), signal.getLatestPrice(), signal.getGeneratedAt(),
                oneMinute, fiveMinute);
        ShadowPosition updated = current.withNearTp(evaluation.state());
        if (!updated.sameNearTp(current)) persistNearTpState(updated);
        if (evaluation.transition()) {
            log.info("FIX-11T Replay fallback Near-TP: runId={}, positionId={}, symbol={}, code={}, state={}, price={}, givebackPct={}, bearish1mStreak={}, detail={}",
                    runId, updated.positionId(), signal.getSymbol(), evaluation.code(), updated.nearTpState(),
                    signal.getLatestPrice(), evaluation.givebackPercent(), updated.nearTpBearishStreak(), evaluation.explanation());
        }
        if (!evaluation.harvestEligible()) return new FallbackNearTpEvaluation(updated, BigDecimal.ZERO, BigDecimal.ZERO);

        BigDecimal soldQty = updated.quantity().multiply(BigDecimal.valueOf(0.50), MC);
            ReplayMinimumExecutionPolicy.Evaluation minimumCheck =
                    replayMinimumExecutionPolicy.evaluate(profile().minimumExecutableNotionalUsdt(), soldQty, signal.getLatestPrice());
        if (!minimumCheck.executable()) {
            updated = updated.withNearTp(new NearTpFailureProtectionPolicy.State(
                    NearTpState.NEAR_TP_REJECTION_DETECTED, updated.nearTpBestPrice(),
                    0, updated.nearTpLastOneMinuteSignalId(), false));
            persistNearTpState(updated);
            log.info("FIX-11T Replay fallback NEAR_TP_HARVEST_SKIPPED: runId={}, positionId={}, symbol={}, reason={}, requestedQty={}, requestedNotional={}, binanceMinimum={}; existing position management continues",
                    runId, updated.positionId(), signal.getSymbol(), minimumCheck.code(), soldQty,
                    minimumCheck.requestedNotional(), minimumCheck.minimumNotional());
            return new FallbackNearTpEvaluation(updated, BigDecimal.ZERO, BigDecimal.ZERO);
        }
        BigDecimal proceeds = soldQty.multiply(signal.getLatestPrice(), MC);
        BigDecimal soldCost = updated.entryPrice().multiply(soldQty, MC);
        BigDecimal pnl = proceeds.subtract(soldCost, MC);
        BigDecimal pnlPct = soldCost.signum() == 0 ? BigDecimal.ZERO : pnl.divide(soldCost, 8, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100));
        updated = updated.withPartialHarvest(soldQty, soldCost, pnl);
        persistNearTpPartialHarvestAtSignal(runId, signal, updated, soldQty, proceeds, pnl, pnlPct, evaluation.explanation());
        log.info("FIX-11T Replay fallback NEAR_TP_PARTIAL_HARVESTED: runId={}, positionId={}, symbol={}, soldQty={}, remainingQty={}, price={}, partialPnl={}",
                runId, updated.positionId(), signal.getSymbol(), soldQty, updated.quantity(), signal.getLatestPrice(), pnl);
        return new FallbackNearTpEvaluation(updated, proceeds, pnl);
    }

    private ShadowPosition updateProfitLock(ShadowPosition p, TradeSignal s) {
        if (s.getLatestPrice() == null || !priceAuthorityPolicy.canUseSignalPrice(s, p.entryTime())) return p;
        ShadowPosition n = profitLockState(p, s.getLatestPrice());
        if (!equalsNullable(p.highest(), n.highest()) || p.profitLockActive() != n.profitLockActive()
                || !equalsNullable(p.profitLockPrice(), n.profitLockPrice())
                || p.profitLockState() != n.profitLockState()
                || !java.util.Objects.equals(p.profitLockRebaseStartedAt(), n.profitLockRebaseStartedAt())) {
            jdbcTemplate.update("UPDATE replay_position SET highest_price_usdt=?, profit_lock_active=?, profit_lock_price_usdt=?, profit_lock_state=?, profit_lock_rebase_started_at=? WHERE id=?",
                    n.highest(), n.profitLockActive(), n.profitLockPrice(), n.profitLockState().name(),
                    n.profitLockRebaseStartedAt() == null ? null : Timestamp.from(n.profitLockRebaseStartedAt()), p.positionId());
        }
        return n;
    }

    private ShadowPosition profitLockState(ShadowPosition p, BigDecimal price) {
        ReplayPolicyProfile settings = profile();
        BigDecimal activation = settings.profitLockActivationPercent();
        BigDecimal highest = p.highest() == null ? price : p.highest().max(price);
        BigDecimal progress = progressPercent(p.entryPrice(), p.takeProfit(), highest);

        if (p.profitLockState() == ProfitLockState.TP_EXTENSION_REBASE
                && progress.compareTo(activation) < 0) {
            // Replay parity with Production FIX-118: preserve the historical lock/legacy flag,
            // but keep it non-executable until the new TP geometry earns activation again.
            return p.withLock(highest, true, p.profitLockPrice(), ProfitLockState.TP_EXTENSION_REBASE,
                    p.profitLockRebaseStartedAt());
        }

        // FIX-118 parity: when REBASE earns activation, rebuild the lock from the current
        // TP geometry instead of retaining the superseded pre-extension lock.
        boolean freshGeometryActivation = p.profitLockState() == ProfitLockState.TP_EXTENSION_REBASE;
        ProfitLockPolicy.State state = profitLockPolicy.evaluate(
                p.entryPrice(), p.takeProfit(), price, highest,
                freshGeometryActivation ? false : (p.profitLockState() == ProfitLockState.ACTIVE || p.profitLockActive()),
                freshGeometryActivation ? null : p.profitLockPrice(),
                settings.dynamicProfitLockEnabled(), activation,
                settings.profitLockInitialPercent(), settings.profitLockTrailStepPercent());
        ProfitLockState nextState = state.active() ? ProfitLockState.ACTIVE : ProfitLockState.INACTIVE;
        return p.withLock(state.highestPrice(), state.active(), state.lockPrice(), nextState, null);
    }

    private ShadowPosition rebaseForExtendedTarget(ShadowPosition p, BigDecimal newTarget, BigDecimal extensionPrice, Instant at) {
        if (p == null || newTarget == null) return p;
        BigDecimal oldTarget = p.takeProfit();
        BigDecimal oldLock = p.profitLockPrice();
        BigDecimal activation = profile().profitLockActivationPercent();
        BigDecimal extensionHighest = p.highest() == null ? p.entryPrice() : p.highest();
        if (extensionPrice != null && extensionPrice.compareTo(extensionHighest) > 0) extensionHighest = extensionPrice;
        ShadowPosition withExtensionHigh = p.withLock(extensionHighest, p.profitLockActive(), p.profitLockPrice(),
                p.profitLockState(), p.profitLockRebaseStartedAt());
        BigDecimal progress = progressPercent(p.entryPrice(), newTarget, extensionHighest);
        if (p.profitLockState() == ProfitLockState.ACTIVE) {
            if (progress.compareTo(activation) < 0) {
                ShadowPosition rebasing = withExtensionHigh.withLock(extensionHighest, true, p.profitLockPrice(), ProfitLockState.TP_EXTENSION_REBASE,
                        at == null ? Instant.now() : at);
                log.info("[FIX-120][REPLAY][TP_GEOMETRY_REBASE] positionId={}, previousState={}, newState={}, oldTarget={}, newTarget={}, " +
                                "extensionPrice={}, highest={}, newGeometryProgressPct={}, oldLock={}, freshLock={}, activationPct={}, geometryRebased=true",
                        p.positionId(), p.profitLockState(), rebasing.profitLockState(), oldTarget, newTarget, extensionPrice,
                        extensionHighest, progress, oldLock, rebasing.profitLockPrice(), activation);
                return rebasing;
            }
            // FIX-120 Production/Replay parity: the old executable lock belongs to the
            // superseded TP geometry. If the extended winner still qualifies, establish a
            // fresh geometry baseline. Raw extensionPrice is current; extensionHighest is the
            // historical-best seed; previousActive/previousLock are deliberately discarded.
            ReplayPolicyProfile settings = profile();
            BigDecimal currentForPolicy = extensionPrice == null ? extensionHighest : extensionPrice;
            ProfitLockPolicy.State rebased = profitLockPolicy.evaluate(
                    p.entryPrice(), newTarget, currentForPolicy, extensionHighest,
                    false, null, settings.dynamicProfitLockEnabled(), activation,
                    settings.profitLockInitialPercent(), settings.profitLockTrailStepPercent());
            if (rebased.active()) {
                ShadowPosition active = withExtensionHigh.withLock(rebased.highestPrice(), true, rebased.lockPrice(), ProfitLockState.ACTIVE, null);
                log.info("[FIX-120][REPLAY][TP_GEOMETRY_REBASE] positionId={}, previousState={}, newState={}, oldTarget={}, newTarget={}, " +
                                "extensionPrice={}, highest={}, newGeometryProgressPct={}, oldLock={}, freshLock={}, activationPct={}, geometryRebased=true",
                        p.positionId(), p.profitLockState(), active.profitLockState(), oldTarget, newTarget, extensionPrice,
                        rebased.highestPrice(), rebased.progressPercent(), oldLock, rebased.lockPrice(), activation);
                return active;
            }
            ShadowPosition rebasing = withExtensionHigh.withLock(rebased.highestPrice(), true, p.profitLockPrice(), ProfitLockState.TP_EXTENSION_REBASE,
                    at == null ? Instant.now() : at);
            log.info("[FIX-120][REPLAY][TP_GEOMETRY_REBASE] positionId={}, previousState={}, newState={}, oldTarget={}, newTarget={}, " +
                            "extensionPrice={}, highest={}, newGeometryProgressPct={}, oldLock={}, freshLock={}, activationPct={}, geometryRebased=true",
                    p.positionId(), p.profitLockState(), rebasing.profitLockState(), oldTarget, newTarget, extensionPrice,
                    rebased.highestPrice(), rebased.progressPercent(), oldLock, rebasing.profitLockPrice(), activation);
            return rebasing;
        }
        if (p.profitLockState() == ProfitLockState.TP_EXTENSION_REBASE) {
            return withExtensionHigh.withLock(extensionHighest, true, p.profitLockPrice(), ProfitLockState.TP_EXTENSION_REBASE,
                    p.profitLockRebaseStartedAt());
        }
        return withExtensionHigh;
    }

    private BigDecimal progressPercent(BigDecimal entry, BigDecimal target, BigDecimal highest) {
        if (entry == null || target == null || highest == null || target.compareTo(entry) <= 0) return BigDecimal.ZERO;
        BigDecimal favorable = highest.subtract(entry);
        if (favorable.signum() < 0) favorable = BigDecimal.ZERO;
        return favorable.multiply(BigDecimal.valueOf(100), MC)
                .divide(target.subtract(entry, MC), 6, RoundingMode.HALF_UP);
    }

    private void persistProfitLockState(ShadowPosition p) {
        requireReplayWrite("replay_position");
        jdbcTemplate.update("UPDATE replay_position SET profit_lock_active=?, profit_lock_price_usdt=?, profit_lock_state=?, profit_lock_rebase_started_at=? WHERE id=?",
                p.profitLockActive(), p.profitLockPrice(), p.profitLockState().name(),
                p.profitLockRebaseStartedAt() == null ? null : Timestamp.from(p.profitLockRebaseStartedAt()), p.positionId());
    }

    private void persistManagement(long runId, TradeSignal s, String code, BigDecimal oldTp, BigDecimal newTp, ShadowPosition p, String explanation) {
        requireReplayWrite("replay_position_management");
        jdbcTemplate.update("""
            INSERT INTO replay_position_management
            (test_run_id,symbol,generated_at,action_code,current_price,old_take_profit,new_take_profit,highest_price,profit_lock_active,profit_lock_price,explanation)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, runId, s.getSymbol(), Timestamp.from(s.getGeneratedAt()), code, s.getLatestPrice(), oldTp, newTp,
                p.highest(), p.profitLockActive(), p.profitLockPrice(), explanation);
    }

    private void persistManagementAtPrice(long runId, String symbol, MarketPriceEventService.PriceEvent event,
                                          String code, BigDecimal oldTp, BigDecimal newTp,
                                          ShadowPosition p, String explanation) {
        requireReplayWrite("replay_position_management");
        jdbcTemplate.update("""
            INSERT INTO replay_position_management
            (test_run_id,symbol,generated_at,action_code,current_price,old_take_profit,new_take_profit,highest_price,profit_lock_active,profit_lock_price,explanation)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, runId, symbol, Timestamp.from(event.observedAt()), code, event.price(), oldTp, newTp,
                p.highest(), p.profitLockActive(), p.profitLockPrice(), explanation);
    }

    private String replayStage(int allocationPercent) {
        if (allocationPercent <= 0) return "NONE";
        if (allocationPercent < 50) return "SCOUT_ENTRY";
        if (allocationPercent < 100) return "CONFIRMATION_ADD";
        return "TREND_ADD";
    }

    private ShadowPosition addToPosition(long runId, ShadowPosition open, TradeSignal signal,
                                         BigDecimal addedQty, BigDecimal addedCost, int addPercent) {
        requireReplayWrite("replay_position");
        BigDecimal newQuantity = open.quantity().add(addedQty, MC);
        BigDecimal newCost = open.cost().add(addedCost, MC);
        BigDecimal newEntry = newCost.divide(newQuantity, 12, RoundingMode.HALF_UP);
        BigDecimal newStop = open.stopLoss();
        if (signal.getStopLoss() != null && (newStop == null || signal.getStopLoss().compareTo(newStop) > 0)) {
            newStop = signal.getStopLoss();
        }
        BigDecimal newTakeProfit = open.takeProfit();
        if (signal.getTakeProfit() != null && (newTakeProfit == null || signal.getTakeProfit().compareTo(newTakeProfit) > 0)) {
            newTakeProfit = signal.getTakeProfit();
        }
        int newPercent = Math.min(100, open.positionPercent() + addPercent);
        jdbcTemplate.update("""
                UPDATE replay_position
                SET entry_price=?, quantity=?, total_cost_usdt=?, position_percent=?,
                    stop_loss_usdt=?, take_profit_usdt=?
                WHERE id=? AND test_run_id=?
                """, newEntry, newQuantity, newCost, newPercent, newStop, newTakeProfit,
                open.positionId(), runId);
        ShadowPosition updated = open.withAdd(newEntry, newQuantity, newCost, newPercent, newStop, newTakeProfit);
        persistNearTpState(updated);
        return updated;
    }

    private void persistBuy(long runId,String symbol,TradeSignal s,ReplayExecutionPrice fresh,BigDecimal qty,BigDecimal budget,int pct,ReplayBuyValidationPolicy.Result d){
        requireReplayWrite("replay_execution");
        jdbcTemplate.update("""
            INSERT INTO replay_execution
            (test_run_id,symbol,side,execution_time,execution_price,quantity,notional_usdt,position_percent,signal_interval,signal_decision,execution_source,execution_code,execution_reason)
            VALUES (?,?,'BUY',?,?,?,?,?,?,?,?,?,?)""",
            runId,symbol,Timestamp.from(fresh.observedAt()),fresh.price(),qty,budget,pct,s.getInterval(),name(s.getDecision()),"REPLAY_LOCAL_BUY",d.code(),d.explanation() + " DecisionPrice=" + s.getLatestPrice() + ", executionPriceObservedAt=" + fresh.observedAt());
    }

    private long openPosition(long runId,String symbol,TradeSignal s,ReplayExecutionPrice fresh,BigDecimal qty,BigDecimal budget,int pct){
        requireReplayWrite("replay_position");
        org.springframework.jdbc.support.GeneratedKeyHolder kh=new org.springframework.jdbc.support.GeneratedKeyHolder();
        jdbcTemplate.update(c->{var ps=c.prepareStatement("""
            INSERT INTO replay_position
            (test_run_id,symbol,status,entry_time,entry_price,quantity,total_cost_usdt,position_percent,stop_loss_usdt,take_profit_usdt,highest_price_usdt)
            VALUES (?,?,'OPEN',?,?,?,?,?,?,?,?)""",java.sql.Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1,runId);ps.setString(2,symbol);ps.setTimestamp(3,Timestamp.from(fresh.observedAt()));ps.setBigDecimal(4,fresh.price());ps.setBigDecimal(5,qty);ps.setBigDecimal(6,budget);ps.setInt(7,pct);ps.setBigDecimal(8,s.getStopLoss());ps.setBigDecimal(9,s.getTakeProfit());ps.setBigDecimal(10,fresh.price());return ps;},kh);
        if (kh.getKey() == null) throw new IllegalStateException("Could not create shadow position");
        return kh.getKey().longValue();
    }

    private void persistSell(long runId,String symbol,TradeSignal s,ShadowPosition p,ExitDecision e,BigDecimal pnl,BigDecimal pnlPct){
        requireReplayWrite("replay_execution");
        BigDecimal notional=s.getLatestPrice().multiply(p.quantity(),MC);
        jdbcTemplate.update("""
            INSERT INTO replay_execution
            (test_run_id,symbol,side,execution_time,execution_price,quantity,notional_usdt,position_percent,signal_interval,signal_decision,execution_source,execution_code,execution_reason,realized_pnl_usdt,realized_pnl_percent)
            VALUES (?,?,'SELL',?,?,?,?,0,?,?,?,?,?,?,?)""",
            runId,symbol,Timestamp.from(s.getGeneratedAt()),s.getLatestPrice(),p.quantity(),notional,s.getInterval(),name(s.getDecision()),"POSITION_MANAGEMENT",e.reason(),e.explanation(),pnl,pnlPct);
    }

    private void closePosition(long runId,long id,TradeSignal s,ExitDecision e,BigDecimal pnl,BigDecimal pnlPct){
        requireReplayWrite("replay_position");
        jdbcTemplate.update("""
            UPDATE replay_position SET status='CLOSED',exit_time=?,exit_price=?,exit_reason=?,exit_explanation=?,realized_pnl_usdt=?,realized_pnl_percent=? WHERE id=? AND test_run_id=?""",
                Timestamp.from(s.getGeneratedAt()),s.getLatestPrice(),e.reason(),e.explanation(),pnl,pnlPct,id,runId);
    }

    private void persistSellAtPrice(long runId, String symbol, MarketPriceEventService.PriceEvent event,
                                    TradeSignal contextSignal, ShadowPosition p, ExitDecision e,
                                    BigDecimal pnl, BigDecimal pnlPct) {
        requireReplayWrite("replay_execution");
        BigDecimal notional = event.price().multiply(p.quantity(), MC);
        jdbcTemplate.update("""
            INSERT INTO replay_execution
            (test_run_id,symbol,side,execution_time,execution_price,quantity,notional_usdt,position_percent,signal_interval,signal_decision,execution_source,execution_code,execution_reason,realized_pnl_usdt,realized_pnl_percent)
            VALUES (?,?,'SELL',?,?,?,?,0,?,?,?,?,?,?,?)
            """, runId, symbol, Timestamp.from(event.observedAt()), event.price(), p.quantity(), notional,
                contextSignal == null ? null : contextSignal.getInterval(),
                contextSignal == null ? null : name(contextSignal.getDecision()),
                "LIVE_PRICE_PROTECTION", e.reason(), e.explanation(), pnl, pnlPct);
    }

    private void closePositionAtPrice(long runId, long id, MarketPriceEventService.PriceEvent event,
                                      ExitDecision e, BigDecimal pnl, BigDecimal pnlPct) {
        requireReplayWrite("replay_position");
        jdbcTemplate.update("""
            UPDATE replay_position
            SET status='CLOSED',exit_time=?,exit_price=?,exit_reason=?,exit_explanation=?,realized_pnl_usdt=?,realized_pnl_percent=?
            WHERE id=? AND test_run_id=?
            """, Timestamp.from(event.observedAt()), event.price(), e.reason(), e.explanation(), pnl, pnlPct, id, runId);
    }

    private void persistNearTpPartialHarvestAtSignal(long runId, TradeSignal signal, ShadowPosition p,
                                                     BigDecimal soldQty, BigDecimal proceeds, BigDecimal pnl,
                                                     BigDecimal pnlPct, String explanation) {
        requireReplayWrite("replay_execution");
        requireReplayWrite("replay_position");
        jdbcTemplate.update("""
            INSERT INTO replay_execution
            (test_run_id,symbol,side,execution_time,execution_price,quantity,notional_usdt,position_percent,signal_interval,signal_decision,execution_source,execution_code,execution_reason,realized_pnl_usdt,realized_pnl_percent)
            VALUES (?,?,'SELL',?,?,?,?,0,?,?,?,?,?,?,?)
            """, runId, signal.getSymbol(), Timestamp.from(signal.getGeneratedAt()), signal.getLatestPrice(), soldQty, proceeds,
                signal.getInterval(), name(signal.getDecision()), "SIGNAL_PRICE_FALLBACK",
                "NEAR_TP_PARTIAL_HARVEST", explanation, pnl, pnlPct);
        jdbcTemplate.update("""
            UPDATE replay_position
            SET quantity=?, total_cost_usdt=?, near_tp_state=?, near_tp_best_price=?, near_tp_bearish_streak=?,
                near_tp_last_1m_signal_id=?, near_tp_harvest_used=1, near_tp_harvested_quantity=?, realized_pnl_usdt=?
            WHERE id=?
            """, p.quantity(), p.cost(), p.nearTpState().name(), p.nearTpBestPrice(), p.nearTpBearishStreak(),
                p.nearTpLastOneMinuteSignalId(), p.nearTpHarvestedQuantity(), p.partialRealizedPnl(), p.positionId());
    }

    private void persistNearTpState(ShadowPosition p) {
        requireReplayWrite("replay_position");
        jdbcTemplate.update("""
            UPDATE replay_position
            SET near_tp_state=?, near_tp_best_price=?, near_tp_bearish_streak=?, near_tp_last_1m_signal_id=?,
                near_tp_harvest_used=?, near_tp_harvested_quantity=?
            WHERE id=?
            """, p.nearTpState().name(), p.nearTpBestPrice(), p.nearTpBearishStreak(), p.nearTpLastOneMinuteSignalId(),
                p.nearTpHarvestUsed(), p.nearTpHarvestedQuantity(), p.positionId());
    }

    private void persistNearTpPartialHarvest(long runId, String symbol, MarketPriceEventService.PriceEvent event,
                                             TradeSignal contextSignal, ShadowPosition p, BigDecimal soldQty,
                                             BigDecimal proceeds, BigDecimal pnl, BigDecimal pnlPct, String explanation) {
        requireReplayWrite("replay_execution");
        requireReplayWrite("replay_position");
        jdbcTemplate.update("""
            INSERT INTO replay_execution
            (test_run_id,symbol,side,execution_time,execution_price,quantity,notional_usdt,position_percent,signal_interval,signal_decision,execution_source,execution_code,execution_reason,realized_pnl_usdt,realized_pnl_percent)
            VALUES (?,?,'SELL',?,?,?,?,0,?,?,?,?,?,?,?)
            """, runId, symbol, Timestamp.from(event.observedAt()), event.price(), soldQty, proceeds,
                contextSignal == null ? null : contextSignal.getInterval(),
                contextSignal == null ? null : name(contextSignal.getDecision()),
                "LIVE_PRICE_PROTECTION", "NEAR_TP_PARTIAL_HARVEST", explanation, pnl, pnlPct);
        jdbcTemplate.update("""
            UPDATE replay_position
            SET quantity=?, total_cost_usdt=?, near_tp_state=?, near_tp_best_price=?, near_tp_bearish_streak=?,
                near_tp_last_1m_signal_id=?, near_tp_harvest_used=1, near_tp_harvested_quantity=?, realized_pnl_usdt=?
            WHERE id=?
            """, p.quantity(), p.cost(), p.nearTpState().name(), p.nearTpBestPrice(), p.nearTpBearishStreak(),
                p.nearTpLastOneMinuteSignalId(), p.nearTpHarvestedQuantity(), p.partialRealizedPnl(), p.positionId());
    }

    private ReplayPolicyProfile profile() {
        ReplayPolicyProfile profile = activeReplayProfile.get();
        if (profile == null) throw new IllegalStateException("FIX-156 Replay policy profile is not active");
        return profile;
    }

    /** FIX-156: resolve only from the supplied immutable historical price-event timeline. */
    private ReplayExecutionPrice resolveReplayPrice(List<MarketPriceEventService.PriceEvent> prices, Instant at) {
        if (prices == null || at == null) return null;
        ReplayExecutionPrice latest = null;
        for (MarketPriceEventService.PriceEvent event : prices) {
            if (event.observedAt().isAfter(at)) break;
            latest = new ReplayExecutionPrice(event.observedAt(), event.price());
        }
        return latest;
    }

    /** FIX-156: package-private fixture hook; production runs always load the frozen store. */
    void activateProfileForTest(ReplayPolicyProfile profile) { activeReplayProfile.set(profile); }
    void clearProfileForTest() { activeReplayProfile.remove(); }

    private String profitLockConfigText() {
        ReplayPolicyProfile profile = profile();
        return "Frozen Replay Profit Lock: activation=" + profile.profitLockActivationPercent().stripTrailingZeros().toPlainString()
                + "%, initial=" + profile.profitLockInitialPercent().stripTrailingZeros().toPlainString()
                + "%, trail=" + profile.profitLockTrailStepPercent().stripTrailingZeros().toPlainString() + "%.";
    }

    private BigDecimal totalPositionPnlPercent(ShadowPosition position, BigDecimal remainingLegPnl) {
        BigDecimal totalPnl = position.partialRealizedPnl().add(remainingLegPnl, MC);
        BigDecimal totalInvestedCost = position.cost().add(position.partialHarvestCostBasis(), MC);
        return totalInvestedCost.signum() == 0 ? BigDecimal.ZERO
                : totalPnl.divide(totalInvestedCost, 8, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
    }

    private BigDecimal percentage(BigDecimal entry,BigDecimal exit){return exit.subtract(entry).multiply(BigDecimal.valueOf(100)).divide(entry,8,RoundingMode.HALF_UP);}
    private boolean bullish(SignalDecision d){return d==SignalDecision.BUY||d==SignalDecision.STRONG_BUY;}
    private boolean bearish(SignalDecision d){return d==SignalDecision.SELL||d==SignalDecision.STRONG_SELL;}
    private String name(SignalDecision d){return d==null?null:d.name();}
    private int intervalOrder(String i){return "1h".equals(i)?0:"5m".equals(i)?1:2;}
    private boolean equalsNullable(BigDecimal a,BigDecimal b){return a==null?b==null:b!=null&&a.compareTo(b)==0;}

    public record ReplayStats(int trades, int wins, int losses, BigDecimal realizedPnl, BigDecimal finalWallet,
                              String priceReplayMode, String logicMode) {}
    private record ReplayExecutionPrice(Instant observedAt, BigDecimal price) {}
    private record FallbackNearTpEvaluation(ShadowPosition position, BigDecimal partialProceeds,
                                            BigDecimal partialRealizedPnl) {}
    private record LivePriceEvaluation(ExitDecision decision, ShadowPosition position,
                                       BigDecimal partialProceeds, BigDecimal partialRealizedPnl) {
        LivePriceEvaluation(ExitDecision decision, ShadowPosition position) {
            this(decision, position, BigDecimal.ZERO, BigDecimal.ZERO);
        }
    }
    private record ExitDecision(boolean exit,String reason,String explanation,BigDecimal newTakeProfit){
        ExitDecision(boolean exit,String reason,String explanation){this(exit,reason,explanation,null);}
        static ExitDecision hold(){return new ExitDecision(false,"HOLD","Position remains open.",null);}
    }
    private record ShadowPosition(long positionId, Instant entryTime, BigDecimal entryPrice, BigDecimal quantity,
                                  BigDecimal cost, int positionPercent, BigDecimal stopLoss, BigDecimal takeProfit,
                                  BigDecimal highest, boolean profitLockActive, BigDecimal profitLockPrice,
                                  ProfitLockState profitLockState, Instant profitLockRebaseStartedAt,
                                  int entryScore, int entryConfidence, int entryTrend, int entryStructure,
                                  int entryMomentum, int entryVolume, NearTpState nearTpState, BigDecimal nearTpBestPrice,
                                  int nearTpBearishStreak, Long nearTpLastOneMinuteSignalId, boolean nearTpHarvestUsed,
                                  BigDecimal nearTpHarvestedQuantity, BigDecimal partialRealizedPnl,
                                  BigDecimal partialHarvestCostBasis) {
        ShadowPosition withLock(BigDecimal h, boolean a, BigDecimal l, ProfitLockState state, Instant rebaseStartedAt) {
            return new ShadowPosition(positionId, entryTime, entryPrice, quantity, cost, positionPercent, stopLoss, takeProfit,
                    h, a, l, state, rebaseStartedAt,
                    entryScore, entryConfidence, entryTrend, entryStructure, entryMomentum, entryVolume,
                    nearTpState, nearTpBestPrice, nearTpBearishStreak, nearTpLastOneMinuteSignalId, nearTpHarvestUsed,
                    nearTpHarvestedQuantity, partialRealizedPnl, partialHarvestCostBasis);
        }
        ShadowPosition withTakeProfit(BigDecimal tp) {
            // FIX-117 Replay parity: TP extension preserves already-earned Near-TP protection
            // exactly like Production. REJECTION_DETECTED keeps its state/best price but clears
            // bearish persistence accumulated under the old geometry. INACTIVE and
            // FAILURE_CONFIRMED keep the pre-FIX-117 reset behavior. Harvested state is terminal.
            NearTpState state = nearTpState;
            BigDecimal bestPrice = nearTpBestPrice;
            int bearishStreak = nearTpBearishStreak;
            Long lastOneMinuteSignalId = nearTpLastOneMinuteSignalId;

            if (!nearTpHarvestUsed) {
                switch (nearTpState) {
                    case INACTIVE, NEAR_TP_FAILURE_CONFIRMED -> {
                        state = NearTpState.INACTIVE;
                        bestPrice = null;
                        bearishStreak = 0;
                        lastOneMinuteSignalId = null;
                    }
                    case NEAR_TP_ARMED -> { }
                    case NEAR_TP_REJECTION_DETECTED -> {
                        bearishStreak = 0;
                        lastOneMinuteSignalId = null;
                    }
                    case NEAR_TP_PARTIAL_HARVESTED -> { }
                }
            }

            return new ShadowPosition(positionId, entryTime, entryPrice, quantity, cost, positionPercent, stopLoss, tp,
                    highest, profitLockActive, profitLockPrice, profitLockState, profitLockRebaseStartedAt,
                    entryScore, entryConfidence, entryTrend, entryStructure, entryMomentum, entryVolume,
                    state, bestPrice, bearishStreak, lastOneMinuteSignalId, nearTpHarvestUsed,
                    nearTpHarvestedQuantity, partialRealizedPnl, partialHarvestCostBasis);
        }
        ShadowPosition withAdd(BigDecimal newEntry, BigDecimal newQuantity, BigDecimal newCost, int newPercent, BigDecimal newStop, BigDecimal newTakeProfit) {
            NearTpState state = nearTpHarvestUsed ? nearTpState : NearTpState.INACTIVE;
            return new ShadowPosition(positionId, entryTime, newEntry, newQuantity, newCost, newPercent, newStop, newTakeProfit,
                    highest, profitLockActive, profitLockPrice, profitLockState, profitLockRebaseStartedAt,
                    entryScore, entryConfidence, entryTrend, entryStructure, entryMomentum, entryVolume,
                    state, nearTpHarvestUsed ? nearTpBestPrice : null, nearTpHarvestUsed ? nearTpBearishStreak : 0,
                    nearTpHarvestUsed ? nearTpLastOneMinuteSignalId : null, nearTpHarvestUsed, nearTpHarvestedQuantity,
                    partialRealizedPnl, partialHarvestCostBasis);
        }
        ShadowPosition withNearTp(NearTpFailureProtectionPolicy.State state) {
            return new ShadowPosition(positionId, entryTime, entryPrice, quantity, cost, positionPercent, stopLoss, takeProfit,
                    highest, profitLockActive, profitLockPrice, profitLockState, profitLockRebaseStartedAt,
                    entryScore, entryConfidence, entryTrend, entryStructure, entryMomentum, entryVolume,
                    state.nearTpState(), state.bestPrice(), state.consecutiveBearishOneMinute(), state.lastEvaluatedOneMinuteSignalId(),
                    state.harvestUsed(), nearTpHarvestedQuantity, partialRealizedPnl, partialHarvestCostBasis);
        }
        ShadowPosition withPartialHarvest(BigDecimal soldQty, BigDecimal soldCost, BigDecimal realizedPnl) {
            return new ShadowPosition(positionId, entryTime, entryPrice, quantity.subtract(soldQty, MC), cost.subtract(soldCost, MC),
                    positionPercent, stopLoss, takeProfit, highest, profitLockActive, profitLockPrice,
                    profitLockState, profitLockRebaseStartedAt,
                    entryScore, entryConfidence, entryTrend, entryStructure, entryMomentum, entryVolume,
                    NearTpState.NEAR_TP_PARTIAL_HARVESTED, nearTpBestPrice, nearTpBearishStreak, nearTpLastOneMinuteSignalId, true,
                    nearTpHarvestedQuantity.add(soldQty, MC), partialRealizedPnl.add(realizedPnl, MC),
                    partialHarvestCostBasis.add(soldCost, MC));
        }
        boolean sameNearTp(ShadowPosition other) {
            return nearTpState == other.nearTpState
                    && equalsDecimal(nearTpBestPrice, other.nearTpBestPrice)
                    && nearTpBearishStreak == other.nearTpBearishStreak
                    && java.util.Objects.equals(nearTpLastOneMinuteSignalId, other.nearTpLastOneMinuteSignalId)
                    && nearTpHarvestUsed == other.nearTpHarvestUsed;
        }
        private boolean equalsDecimal(BigDecimal a, BigDecimal b) {
            return a == null ? b == null : b != null && a.compareTo(b) == 0;
        }
    }

}
